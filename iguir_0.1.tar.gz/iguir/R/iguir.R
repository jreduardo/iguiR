#' @title iguir: interfaces gráfico interativas com o R
#' @name iguir
#'
#' @description Exemplificação da utilização dos pacotes R shiny, rpanel
#' e gWidegts para construção de interfaces gráficas interativas..
#'
#' @param topic tópico na construção das interfaces a ser abordado pelo exemplo
#'
#' @param package biblioteca do R cujo será utilizada para construção
#' das interfaces gráfico interativas.
#' 
#' @return um gráfico com propriedades alteradas conforme controladores
#' da janela interativa contruída com base nos parâmetros informados
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(iguir)
#'
#' ## Exibindo os tópicos e pacotes
#' iguir()
#'
#' ## Interfaces interativas
#' iguir(topic = "select", package = "rpanel")
#' iguir(topic = "select", package = "shiny")
#' iguir(topic = "select", package = "gwidgets")
#' }

iguir <- function(topic = NULL, package = NULL){
    topics <- c("text", "slider", "select", "radio", "numeric",
                "checkboxgroup", "checkbox", "button", "listbox")
    packages <- c("gwidgets", "rpanel", "shiny")
    if(is.null(topic) | is.null(package)){
        cat("Os exemplos abordam os seguinte tópicos\n", "->", topics,
            "\ndentro dos pacotes:\n", "->", packages, "\n")
    }
    if(!is.null(topic) & !is.null(package)){
        fun <- paste(package, "_", topic, sep="")
        do.call(fun, args=list())
    }
    ## else {
    ##     stop("argumento topic ou package inválido")
    ## }
    invisible()
}
