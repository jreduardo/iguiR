#' @title Toy Examples: text in package shiny
#' @name shiny_text
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote shiny
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(shiny)
#' shiny_text()
#' }

shiny_text <- function(){
    example <- "hist_text"
    dirShiny <- system.file('shiny', package='iguir')
    dirExample <- paste(dirShiny, "/", example, sep="")
    runApp(dirExample)
    invisible()
}

#' @title Toy Examples: slider in package shiny
#' @name shiny_slider
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote shiny
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(shiny)
#' shiny_slider()
#' }

shiny_slider <- function(){
    example <- "hist_slider"
    dirShiny <- system.file('shiny', package='iguir')
    dirExample <- paste(dirShiny, "/", example, sep="")
    runApp(dirExample)
    invisible()
}

#' @title Toy Examples: select in package shiny
#' @name shiny_select
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote shiny
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(shiny)
#' shiny_select()
#' }

shiny_select <- function(){
    example <- "hist_select"
    dirShiny <- system.file('shiny', package='iguir')
    dirExample <- paste(dirShiny, "/", example, sep="")
    runApp(dirExample)
    invisible()
}

#' @title Toy Examples: radiobutton in package shiny
#' @name shiny_radio
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote shiny
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(shiny)
#' shiny_radio()
#' }

shiny_radio <- function(){
    example <- "hist_radio"
    dirShiny <- system.file('shiny', package='iguir')
    dirExample <- paste(dirShiny, "/", example, sep="")
    runApp(dirExample)
    invisible()
}

#' @title Toy Examples: numeric in package shiny
#' @name shiny_numeric
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote shiny
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(shiny)
#' shiny_numeric()
#' }

shiny_numeric <- function(){
    example <- "hist_numeric"
    dirShiny <- system.file('shiny', package='iguir')
    dirExample <- paste(dirShiny, "/", example, sep="")
    runApp(dirExample)
    invisible()
}

#' @title Toy Examples: checkboxgroup in package shiny
#' @name shiny_checkboxgroup
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote shiny
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(shiny)
#' shiny_checkboxgroup()
#' }

shiny_checkboxgroup <- function(){
    example <- "hist_checkboxgroup"
    dirShiny <- system.file('shiny', package='iguir')
    dirExample <- paste(dirShiny, "/", example, sep="")
    runApp(dirExample)
    invisible()
}

#' @title Toy Examples: checkbox in package shiny
#' @name shiny_checkbox
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote shiny
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(shiny)
#' shiny_checkbox()
#' }

shiny_checkbox <- function(){
    example <- "hist_checkbox"
    dirShiny <- system.file('shiny', package='iguir')
    dirExample <- paste(dirShiny, "/", example, sep="")
    runApp(dirExample)
    invisible()
}

#' @title Toy Examples: button in package shiny
#' @name shiny_button
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote shiny
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(shiny)
#' shiny_button()
#' }

shiny_button <- function(){
    example <- "hist_button"
    dirShiny <- system.file('shiny', package='iguir')
    dirExample <- paste(dirShiny, "/", example, sep="")
    runApp(dirExample)
    invisible()
}

#' @title Toy Examples: listbox in package shiny
#' @name shiny_listbox
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote shiny
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(shiny)
#' shiny_listbox()
#' }

shiny_listbox <- function(){
    example <- "transform"
    dirShiny <- system.file('shiny', package='iguir')
    dirExample <- paste(dirShiny, "/", example, sep="")
    runApp(dirExample)
    invisible()
}
