#' @title Toy Examples: text in package gWidgets
#' @name gwidgets_text
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote gWidgets
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(gWidgets)
#' options(guiToolkit="tcltk")
#'
#' gwidgets_text()
#' }

gwidgets_text <- function(){
    x <- precip
    ht <- hist(x, plot=FALSE)
    ## Função reativa
    hist.reactive <- function(...){
        plot(ht, col="#006666",
             ylab="Frequência absoluta",
             xlab="Precipitação",
             main=svalue(main),
             sub=svalue(sub))
    }
    ## Interface
    w <- gwindow("Histograma")
    g <- gframe(text="Texto para o título:", container=w)
    main <- gedit(text=NULL,
                  initial.msg="Insira e pressione Enter",
                  coerce.with="as.character",
                  container=g, handler=hist.reactive)
    g <- gframe(text="Texto para o subtítulo:", container=w)
    sub <- gedit(text=NULL,
                 initial.msg="Insira e pressione Enter",
                 coerce.with="as.character",
                 container=g, handler=hist.reactive)
    invisible()
}

#' @title Toy Examples: slider in package gWidgets
#' @name gwidgets_slider
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote gWidgets
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(gWidgets)
#' options(guiToolkit="tcltk")
#'
#' gwidgets_slider()
#' }

gwidgets_slider <- function(){
    x <- precip
    a <- extendrange(x, f=0.05)
    ## Função reativa
    hist.reactive <- function(...){
        bks <- seq(a[1], a[2], length.out=svalue(nclass)+1)
        hist(x,
             breaks=bks,
             main=NULL,
             col="#008A8A",
             ylab="Frequência absoluta",
             xlab="Precipitação")
    }
    ## Interface
    w <- gwindow("Histograma")
    glabel(text="Escolha o número de classes:", container=w)
    nclass <- gslider(from=1, to=30, by=1, value=10, expand=TRUE,
                      container=w, handler=hist.reactive)
    invisible()
}

#' @title Toy Examples: select in package gWidgets
#' @name gwidgets_select
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote gWidgets
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(gWidgets)
#' options(guiToolkit="tcltk")
#'
#' gwidgets_select()
#' }

gwidgets_select <- function(){
    Nclass <- c("Sturges", "Scott", "Freedman-Diaconis")
    Obj <- c("precip","rivers","islands")
    ## Função reativa
    hist.reactive <- function(...){
        L <- switch(svalue(obj),
                    precip=list(x=precip,
                        xlab="Precipitação anual média (polegadas)"),
                    rivers=list(x=rivers,
                        xlab="Comprimento dos rios (milhas)"),
                    islands=list(x=islands,
                        xlab="Área de ilhas (1000 milhas quadradas)"))
        hist(L$x,
             breaks = svalue(nclass),
             col = "#8F0047",
             main = NULL,
             ylab = "Frequência absoluta",
             xlab = L$xlab)
        rug(L$x)
    }
    ## Interface
    w <- gwindow("Histograma")
    glabel(text="Escolha o conjunto de dados:", container=w)
    obj <- gcombobox(items=Obj, selected=1, container=w,
                     handler=hist.reactive)
    glabel(text="Escolha a regra para número de classes:", container=w)
    nclass <- gcombobox(items=Nclass, selected=1, container=w,
                        handler=hist.reactive)
    invisible()
}

#' @title Toy Examples: radiobutton in package gWidgets
#' @name gwidgets_radio
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote gWidgets
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(gWidgets)
#' options(guiToolkit="tcltk")
#'
#' gwidgets_radio()
#' }

gwidgets_radio <- function(){
    x <- precip
    ht <- hist(x, plot=FALSE)
    choices <- c(Turquesa="#00CC99",
                 Azul="#0066FF",
                 Rosa="#FF3399",
                 Laranja="#FF6600",
                 Roxo="#660066",
                 "Verde limão"="#99FF33")
    ## Função reativa
    hist.reactive <- function(...){
        plot(ht,
             col=choices[svalue(col)],
             main=NULL,
             ylab="Frequência absoluta",
             xlab="Precipitação")
    }
    ## Interface
    w <- gwindow("Histograma")
    g <- gframe(text="Escolha a cor para as barras:", container=w)
    col <- gradio(items=names(choices),
                  selected=1,
                  container=g, handler=hist.reactive)
    invisible()
}

#' @title Toy Examples: spinbutton in package gWidgets
#' @name gwidgets_numeric
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote gWidgets
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(gWidgets)
#' options(guiToolkit="tcltk")
#'
#' gwidgets_numeric()
#' }

gwidgets_numeric <- function(){
    x <- precip
    ht <- hist(x, plot=FALSE)
    ## Função reativa
    hist.reactive <- function(...){
        m <- svalue(mar)
        par(mar=c(m, m, 1, 1))
        plot(ht, col="#660066",
             main=NULL, axes=FALSE, ann=FALSE,
             xaxt="n", yaxt="n")
        box(bty="L")
        axis(side=1, cex.axis=svalue(cexaxis))
        axis(side=2, cex.axis=svalue(cexaxis))
        title(ylab="Frequência absoluta",
              xlab="Precipitação",
              line=svalue(line))
    }
    ## Interface
    w <- gwindow("Histograma")
    g <- gframe(text="Distância das margens", container=w)
    mar <- gspinbutton(from=3, to=7, by=0.5, value=5,
                       container=g, handler=hist.reactive)
    svalue(mar) <- 5
    g <- gframe(text="Tamanho do texto dos eixos:", container=w)
    cexaxis <- gspinbutton(from=0.5, to=2, by=0.1, value=1,
                           container=g, handler=hist.reactive)
    svalue(cexaxis) <- 1
    g <- gframe(text="Distância dos rótulos dos eixos:", container=w)
    line <- gspinbutton(from=1, to=4, by=0.1, value=3,
                        container=g, handler=hist.reactive)
    svalue(line) <- 3
    invisible()
}

#' @title Toy Examples: checkboxgroup in package gWidgets
#' @name gwidgets_checkboxgroup
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote gWidgets
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(gWidgets)
#' options(guiToolkit="tcltk")
#'
#' gwidgets_checkboxgroup()
#' }

gwidgets_checkboxgroup <- function(){
    x <- precip
    ht <- hist(x, plot=FALSE)
    nc <- length(ht$counts)
    cols <- c(Vermelho="#F81D54", Amarelo="#FF9F1E", Azul="#2791E1",
              Verde="#72F51D")
    cols2 <- c(cols, rev(cols))
    ## Função reativa
    hist.reactive <- function(...){
        if(sum(input$colors == 0)){
            seqcol <- colorRampPalette("white")
        }
        if(sum(input$colors != 0)){
            seqcol <- colorRampPalette(cols2[input$colors])
        }
        plot(ht, col=seqcol(nc),
             main=NULL,
             ylab="Frequência absoluta",
             xlab="Precipitação")
    }
    ## Interface
    w <- gwindow("Histograma")
    g <- gframe(text="Escolha as cores para interpolar:", container=w)
    colors <- gcheckboxgroup(items=names(cols2),
                             checked=c(TRUE, is.na(cols2)[-1]),
                             container=g, handler=hist.reactive)
    invisible()
}

#' @title Toy Examples: checkbox  in package gWidgets
#' @name gwidgets_checkbox
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote gWidgets
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(gWidgets)
#' options(guiToolkit="tcltk")
#'
#' gwidgets_checkbox()
#' }

gwidgets_checkbox <- function(){
    x <- precip
    ht <- hist(x, plot=FALSE)
    col <- rep("#3366CC", length(ht$counts))
    ## Função reativa
    hist.reactive <- function(...){
        if(svalue(modal)){
            col[which.max(ht$counts)] <- "#142952"
        }
        plot(ht, col=col, main=NULL,
             ylab="Frequência absoluta",
             xlab="Precipitação")
        if(svalue(rg)){
            rug(x, col=col[1], lwd=1.5)
        }
    }
    ## Inteerface
    w <- gwindow("Histograma")
    rg <- gcheckbox(text="Marcar sobre eixo com os valores?",
                    checked=FALSE, container=w, handler=hist.reactive)
    modal <- gcheckbox(text="Destacal a classe modal?",
                       checked=FALSE, container=w,
                       handler=hist.reactive)
    invisible()
}

#' @title Toy Examples: button in package gWidgets
#' @name gwidgets_button
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote gWidgets
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(gWidgets)
#' options(guiToolkit="tcltk")
#'
#' gwidgets_button()
#' }

gwidgets_button <- function(){
    x <- precip
    ht <- hist(x, plot = FALSE)
    ## Função reativa
    hist.reactive <- function(...){
        col <- sample(colors(), size=1)
        plot(ht, main=NULL,
             ylab="Frequência absoluta", xlab="Precipitação",
             col=col, sub=col)
    }
    ## Interface
    w <- gwindow("Histograma")
    gbutton(text="Nova cor!", container=w, handler=hist.reactive)
    invisible()
}

#' @title Toy Examples: listbox in package gWidgets
#' @name gwidgets_listbox
#'
#' @description Exemplificação da utilização dos controladores providos
#' pelo pacote gWidgets
#' 
#' @export
#' @examples
#' \donttest{
#' ##--------------------------------------------
#'
#' require(gWidgets)
#' options(guiToolkit="tcltk")
#'
#' gwidgets_listbox()
#' }

gwidgets_listbox <- function(){
    x <- cars$speed
    y <- cars$dist
    trans <- c("Identidade", "Quadrado", "RaizQuadrada", "Log10") 
    ## Função reativa
    transformation <- function(...) {
        ## Transformando as variáveis
        tx <- svalue(tx)
        x <- switch(tx,
                    Identidade = x,
                    Quadrado = x^2,
                    RaizQuadrada = sqrt(x),
                    Log10 = log10(x)
                    )
        ## Protegendo a função devido a primeira seleção
        if(is.null(x)){ x <- cars$speed; tx <- "Identidade"}
        ## Exibindo graficamente
        plot(y ~ x, pch=19, main = "Gráfico de Dispersão",
             xlab = paste(tx, "de X", sep=" "))
    }
    ## Interface
    win <- gwindow("Transformação de Variáveis")
    tx <- gtable(trans, cont=win, height=100,
                 handler = transformation)
    names(tx) <- "Tranformação em X"
    invisible()
}
